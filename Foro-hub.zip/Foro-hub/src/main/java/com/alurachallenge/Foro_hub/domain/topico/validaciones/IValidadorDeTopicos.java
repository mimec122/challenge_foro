package com.alurachallenge.Foro_hub.domain.topico.validaciones;

import com.alurachallenge.Foro_hub.domain.topico.DatosTopico;

public interface IValidadorDeTopicos {
    void validar(DatosTopico datosTopico);
}
