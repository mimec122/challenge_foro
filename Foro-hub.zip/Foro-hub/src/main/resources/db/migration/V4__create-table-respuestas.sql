CREATE TABLE respuestas (
    id BIGSERIAL PRIMARY KEY,
    mensaje VARCHAR(100) NOT NULL,
    topico_id BIGINT NOT NULL,
    fecha_creacion TIMESTAMP NOT NULL,
    usuario_id BIGINT NOT NULL,
    solucion VARCHAR(300) NOT NULL,

    CONSTRAINT fk_respuestas_topico_id FOREIGN KEY (topico_id) REFERENCES topicos (id),
    CONSTRAINT fk_respuestas_usuario_id FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
);
