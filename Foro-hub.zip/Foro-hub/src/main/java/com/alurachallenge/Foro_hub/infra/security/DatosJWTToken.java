package com.alurachallenge.Foro_hub.infra.security;

public record DatosJWTToken(String JWTtoken) {
}
