package com.alurachallenge.Foro_hub.domain.usuario;

public enum Rol {
    ADMINISTRADOR,
    MODERADOR,
    USUARIO
}
