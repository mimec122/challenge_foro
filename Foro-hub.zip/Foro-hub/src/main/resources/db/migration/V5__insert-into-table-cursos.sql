DELETE FROM `foro-hub`.`cursos`;

INSERT INTO `foro-hub`.`cursos` (`id`, `nombre`, `categoria`)
VALUES ('1', 'Aprendiendo backend', 'BACKEND');
INSERT INTO `foro-hub`.`cursos` (`id`, `nombre`, `categoria`)
VALUES ('2', 'Aprendiendo frontend', 'FRONTEND');
INSERT INTO `foro-hub`.`cursos` (`id`, `nombre`, `categoria`)
VALUES ('3', 'Aprendiendo Java', 'JAVA');
INSERT INTO `foro-hub`.`cursos` (`id`, `nombre`, `categoria`)
VALUES ('4', 'Principios del emprendimiento', 'EMPRENDIMIENTO');
INSERT INTO `foro-hub`.`cursos` (`id`, `nombre`, `categoria`)
VALUES ('5', 'Logica de programacion', 'PROGRAMACION');
