package com.alurachallenge.Foro_hub.domain.respuesta.validaciones;

import com.alurachallenge.Foro_hub.domain.respuesta.DatosRespuesta;

public interface IValidadorDeRespuestas {
    void validar(DatosRespuesta datosRespuesta);
}
