package com.alurachallenge.Foro_hub.domain.usuario.validaciones;

import com.alurachallenge.Foro_hub.domain.usuario.DatosUsuario;

public interface IValidadorDeUsuarios {
    void validar(DatosUsuario datosUsuario);
}
