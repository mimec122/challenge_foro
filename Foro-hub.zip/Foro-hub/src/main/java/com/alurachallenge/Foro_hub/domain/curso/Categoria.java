package com.alurachallenge.Foro_hub.domain.curso;

public enum Categoria {
    BACKEND,
    FRONTEND,
    JAVA,
    EMPRENDIMIENTO,
    PROGRAMACION
}
